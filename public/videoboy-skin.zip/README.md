# VIDEOBOY

A dot-matrix handheld skin for the [Video.js v10](https://videojs.org) player.

Full colour while it plays. The moment it stops, the screen becomes a four-tone dot-matrix panel: a boot logo, a Press Start menu, a Pause window, an end card, and static when the signal drops. The controls (D-pad, seek strip, Menu, Full, play and mute keys, speaker-grille volume) live on the console below the screen, so nothing covers the picture while it plays. In fullscreen the console floats over the film and then steps away to a single outlined progress line.

Designed and built by [Victor Ibidunmoye](https://cad.victoribidunmoye.me) for the #Video.js Skins Design Challenge.

## Use it

```bash
npm i @videojs/html @videojs/mux-video
```

```js
import './videoboy/skin';        // the src folder of this project
import './videoboy/videoboy.css';
import '@videojs/html/media/mux-video';
```

```html
<video-player>
  <videoboy-skin data-theme="tangerine" poster-time="36">
    <mux-video src="https://stream.mux.com/YOUR_PLAYBACK_ID.m3u8" playsinline crossorigin="anonymous"></mux-video>
  </videoboy-skin>
</video-player>
```

Any `<video>` works in place of `<mux-video>`. Mux instant clips work too: add `asset_start_time` and `asset_end_time` to the stream URL, and the skin clips the seek-preview storyboard to match.

### Attributes on `<videoboy-skin>`

| Attribute | Values | What it does |
| --- | --- | --- |
| `data-theme` | `tangerine` (default), `classic`, `night` | Picks a palette for the shell, keys and LCD tones. |
| `poster` | image URL | The start screen draws this image in dot-matrix (for Mux: `https://image.mux.com/<id>/thumbnail.webp?time=36`). The media is not touched until Start. |
| `poster-time` | seconds | Without `poster`, the start screen parks the media on this frame. Playback still starts at 0. |
| `keyboard` | `page` | The player's keys work anywhere on the page, not only when it has focus. Use on one player per page. |
| `no-chime` | (boolean) | Turns off the short start chime. The chime only plays from a user gesture, scaled by the player volume, never when muted. |

### Tokens

Every colour and radius is a custom property on `videoboy-skin`, so a site can restyle the handheld from its own CSS:

```css
videoboy-skin {
  --vb-accent: #2f7cf6;          /* seek fill, lit menu key, grille */
  --vb-key: #2f7cf6;             /* play and mute key faces */
  --vb-key-hi: #74a6f9;
  --vb-key-lo: #1b4fa6;
  --vb-key-ink: #fff;            /* icons on the play and mute keys */
  --vb-led: #5b9bff;             /* power LED */
  --vb-lcd-0: #0b1d3a;           /* darkest LCD tone ... */
  --vb-lcd-3: #dbe8ff;           /* ... lightest */
  --vb-radius-corner: 48px;      /* the handheld's big bottom-right corner */
}
```

The full list is at the top of `src/videoboy.css`.

## How the dot-matrix works

`src/lcd.ts` defines `<vb-lcd>`. It captures the current frame into a small canvas, samples it onto a grid of about 160 dots across, auto-levels the luminance (2nd to 98th percentile), ordered-dithers it with a 4×4 Bayer matrix into four tones, and draws each dot with a gap and a soft drop shadow, like a reflective LCD. On pause the colour picture first pixelates up to dot size, then snaps to the four tones; on play it releases back. While paused, seeking redraws the panel, so scrubbing shows the new frame in dot-matrix.

If a frame cannot be read (footage from another domain whose server does not allow cross-origin access, CORS), the panel falls back to an SVG filter that maps the picture onto the same four tones.

`<vb-lcd>` also writes the screen's mode to the container (`data-lcd="start | play | pause | end | error"`, `data-waiting`), which the power LED and the screen windows follow.

## Controls

| Part | Does |
| --- | --- |
| Power light | Shows status: lit while playing, low when stopped, blinking while loading, red on error. |
| D-pad | Left/right seek 5 s, up/down volume one slot. One tab stop; arrows move between arms; hold to repeat. A press anywhere in its circle picks the arm by angle. |
| Seek strip | Drag the cartridge to move through the video. Hover for a preview frame (Mux storyboard). |
| Menu key | A handheld menu window: captions, speed, quality, audio track, motion, picture-in-picture. Video.js menu parts, so arrow keys, Enter and Escape work, and rows the source can't offer are hidden. Hotkey Shift. |
| Full key | Fullscreen on and off. |
| Mute key | Mute and unmute; the icon shows which. Printed Z, its keyboard key. |
| Play key | Play, pause, replay; the icon shows which. Printed X, its keyboard key. |
| Speaker grille | Volume slider, six slots lit from the bottom: drag, click or scroll. |

Keyboard, laid out like a handheld emulator:

| Key | Does |
| --- | --- |
| A / D, ← / → | Seek 5 s (D-pad left, right) |
| W / S, ↑ / ↓ | Volume one slot (D-pad up, down) |
| X, Space, K | Play, pause, replay (Play key) |
| Z, M | Mute (Mute key) |
| Enter, F | Fullscreen (Full key). Enter works when no control has focus. |
| Shift on its own | Open the menu (Menu key). In the menu: arrows move, Enter chooses, Esc backs out. |
| J / L | Seek 10 s |
| 0–9, Home, End | Jump to 0–90%, start, end |
| C | Captions on or off |
| Tab | Next control. The D-pad is one stop; arrows move between its arms. |

With `keyboard="page"` on `<videoboy-skin>`, these work anywhere on the page, not only when the player has focus. Keys typed in fields, pressed on page controls, or inside another player are left alone.

## Accessibility

```bash
npm run test:a11y   # builds, serves, runs axe-core over every theme, width and state
```

The script writes `public/a11y-report.json` (every run and rule) and `public/a11y-tree.txt` (the player's accessibility tree, as a screen reader is given it), and fails on any violation. Set `VB_CHROME` to use a Chromium already on the machine.

- 0 axe-core violations across 96 runs: WCAG 2.2 A/AA and best-practice rules, three themes, three widths, ten states (boot, start, playing, paused, menu, submenu, tooltip, muted, ended, error), and the demo page in all three themes at 1440 and 390 px.
- Labels and timecodes reach at least 6.6:1; key icons at least 5.7:1.
- Every control is a Video.js component with its own name and shortcut; the status announcer reports changes. The LCD canvas is hidden from assistive tech.
- Motion: the menu's Motion row offers Auto (follows `prefers-reduced-motion`), Full and Reduced, remembered per browser. Reduced: no mosaic transition, no blinking, no boot drop.
- `forced-colors`: the handheld redraws itself in system colours.
- Keys are 40 px or more; the D-pad reads presses across its whole circle; seek strip, grille and menu rows are 38 to 44 px tall.
- These are automated checks in Chromium, not a full accessibility audit. Manual testing with screen readers (NVDA, VoiceOver) and in Firefox and Safari has not been done yet.

## Develop

```bash
npm install
npm run dev        # demo page at http://localhost:5173
npm run build      # static site in dist/
```

Set `VITE_MUX_PLAYBACK_ID` (see `.env.production`) to stream from Mux; add `?local` to the URL to use the bundled clips.

## Credits and licences

- Skin code: Apache License 2.0 (see `LICENSE`).
- Fonts: Press Start 2P and Silkscreen, SIL Open Font License 1.1 (see `src/fonts`).
- Demo film: a two-minute cut (4:50 to 6:50) of *Tears of Steel*, streamed as a Mux instant clip (`?asset_start_time=290&asset_end_time=410`) of the full asset, © Blender Foundation, [mango.blender.org](https://mango.blender.org), CC BY 3.0. Playground clips and captions are original.
